import React from 'react';
import { Text, View } from 'react-native';

const NoteScreen = () => {
    const id = props.navigation.getParam('id');
    return (
        <View style={{ padding: 10 }}>
            <Text>Это примечание! {id}</Text>
        </View>
    );
};
export default NoteScreen;