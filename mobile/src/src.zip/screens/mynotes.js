import React from 'react';
import { Text, View } from 'react-native';

const MyNotes = () => {
	return (
		
	<View style={{ flex: 1, justifyContent: 'center', alignItems: 'center'}}>
		<Text>Мои заметки</Text>
		
	</View>
	);
};
MyNotes.navigationOptions = {
	title: 'Мои заметки'
	};
export default MyNotes;